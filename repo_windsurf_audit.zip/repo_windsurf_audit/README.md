# Auditoria de Windsurf (hooks) - paquete de despliegue

Registra lo que se escribe y responde en Windsurf (Cascade) en un log local y lo envia a Exabeam por syslog UDP.
Se instala por Cortex XDR con `cortex/cortex_instalar_windsurf_audit.py`.

## Estructura

| Ruta | Que es |
|---|---|
| `fuente/` | Los 5 archivos fuente (se editan aqui) |
| `paquete/windsurf_audit_windows.zip` | Paquete que descarga Cortex (se genera desde `fuente/`) |
| `SHA256.txt` | Hash del zip: es el valor de `EXPECTED_ZIP_SHA256` en Cortex |
| `construir_paquete.py` | Regenera el zip y `SHA256.txt` (reproducible: mismos archivos = mismo hash) |
| `cortex/cortex_instalar_windsurf_audit.py` | Script para Cortex XDR |

Archivos de `fuente/`:

| Archivo | Obligatorio | Funcion |
|---|---|---|
| `windsurf_audit.ps1` | Si | El script que audita (lo ejecuta Windsurf en cada hook) |
| `policy.json` | Si | Reglas de riesgo (modo `audit`: no bloquea) |
| `install.ps1` | Si | Instalador (crea carpetas, copia archivos, genera `hooks.json`) |
| `ver_logs.ps1` | No | Visor del log local |
| `diagnostico_siem.ps1` | No | Prueba de conectividad y envio al SIEM |

## Publicar en GitHub

```
git init
git add -A
git commit -m "Version 1"
git tag v1
git branch -M main
git remote add origin https://github.com/ORGANIZACION/REPOSITORIO.git
git push -u origin main --tags
```

## Configurar Cortex

En `cortex/cortex_instalar_windsurf_audit.py` (o como parametros):

- `GITHUB_REPO`: `"ORGANIZACION/REPOSITORIO"` (repositorio publico)
- `GITHUB_REF`: `"v1"` (un tag o un SHA de commit; evitar `main`)
- `EXPECTED_ZIP_SHA256`: el hash de `SHA256.txt`

Orden recomendado de pruebas:

1. Un equipo: `only_ips = "<ip del equipo>"` y `dry_run = true` (clona y valida, no instala).
2. El mismo equipo sin `dry_run`. Reiniciar Windsurf, mandar un prompt y confirmar que llega a Exabeam.
3. Ampliar `only_ips` a un rango y despues dejarlo vacio para toda la flota.

El log de cada equipo queda en `C:\ProgramData\WindsurfAudit\install.log`.

## Actualizar una version

1. Editar los archivos de `fuente/`.
2. `python construir_paquete.py` (actualiza el zip y `SHA256.txt`).
3. `git add -A && git commit -m "..." && git tag v2 && git push --tags`
4. En Cortex: `GITHUB_REF = "v2"` y el nuevo `EXPECTED_ZIP_SHA256`.

## Antes de hacer publico el repositorio

Todo lo que este aqui sera visible para cualquiera. Revisa en especial:

- `fuente/windsurf_audit.ps1`: contiene la IP interna del SIEM (`$SYSLOG_HOST`) y el puerto.
- `fuente/policy.json`: muestra que patrones se vigilan (comandos, rutas, secretos) y con que reglas.
- Los scripts describen como funciona la auditoria.

Si eso no debe ser publico, mantener el repositorio privado o quitar esos datos antes de publicar.

## Requisitos en el equipo

Windows 10/11 con PowerShell 5.1, Windsurf con plan de pago (los hooks no funcionan en el plan gratuito),
Git instalado (para el clon) y salida UDP 514 hacia el SIEM.
