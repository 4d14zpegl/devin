# -*- coding: utf-8 -*-
"""
cortex_instalar_windsurf_audit.py   (v2)

Script para Cortex XDR (se ejecuta en el equipo, como SYSTEM). Solo libreria estandar.
Archivo en ASCII a proposito (la consola de Windows/Cortex puede fallar con acentos).

FLUJO
  1. Detecta que usuarios del equipo tienen Windsurf/Devin.
       - Si ninguno: escribe una linea en el log y TERMINA (no descarga nada).
  2. CLONA el repo PUBLICO de GitHub (git clone --depth 1) en una carpeta temporal.
  3. Dentro del repo busca el paquete  windsurf_audit_windows.zip  y lo descomprime.
  4. Ejecuta el instalador del paquete (install.ps1) UNA VEZ POR USUARIO con Windsurf.
       Como Cortex corre como SYSTEM, se lanza con USERPROFILE y USERNAME del usuario
       destino: asi install.ps1 instala en SU perfil (no en el de SYSTEM).
  5. Deja el resultado en el log:  %ProgramData%\\WindsurfAudit\\install.log

ENTRADA PARA CORTEX
  Punto de entrada:  run(repo, ref, expected_zip_sha256, dry_run, skip_test, only_ips, siem_ip, siem_port)
                     (todos opcionales)
  Tambien corre como script normal:
      python cortex_instalar_windsurf_audit.py [repo ref sha256 dry_run skip_test only_ips siem_ip siem_port]

MODO PILOTO (probar primero con una IP)
  only_ips = "10.1.2.3"  (o varias separadas por coma, o rangos CIDR: "10.1.2.0/24")
     El script solo actua si el equipo tiene una de esas IP; en los demas deja una linea SKIP en el log
     y no hace nada (no detecta, no descarga, no instala).
  siem_ip / siem_port (opcionales, SOLO PRUEBAS)
     Cambia a que IP/puerto manda eventos el script instalado, para probar contra un receptor de prueba
     y no contra el Exabeam de produccion. Para pasar a produccion, ejecutar de nuevo SIN estos valores.
"""
import datetime
import hashlib
import ipaddress
import os
import re
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

try:
    import winreg
except ImportError:          # no es Windows (solo para pruebas)
    winreg = None

# ============================ CONFIG ============================
GITHUB_REPO         = "OWNER/REPO"   # <-- CAMBIAR: repo PUBLICO "organizacion/repositorio" (o https://github.com/org/repo)
GITHUB_REF          = "main"         # rama, tag o SHA de commit (40 hex). RECOMENDADO: un tag o un SHA fijo
FALLBACK_ZIP_IF_NO_GIT = False       # False: sin git instalado el script aborta (solo clona).
                                     # True: sin git, descarga el zip PUBLICO del mismo repo
GIT_TIMEOUT         = 180            # segundos para el clone
ZIP_NAME            = "windsurf_audit_windows.zip"   # nombre del paquete dentro del repo
EXPECTED_ZIP_SHA256 = ""             # opcional: SHA-256 de ese zip; si no coincide, aborta

ONLY_IPS            = ""             # piloto: IP(s) o CIDR separados por coma; vacio = todos los equipos
SIEM_IP_OVERRIDE    = ""             # SOLO PRUEBAS: IP de un receptor syslog de prueba (vacio = la del paquete)
SIEM_PORT_OVERRIDE  = ""             # SOLO PRUEBAS: puerto del receptor de prueba (vacio = el del paquete)

SKIP_TEST           = False          # True: install.ps1 con -SkipTest (sin evento de prueba al SIEM)
APP_PATTERNS        = ("windsurf", "devin")   # nombres a buscar (carpetas / registro)
INSTALL_ALL_IF_MACHINE_WIDE = True   # si esta instalado a nivel de equipo, instalar en todos los perfiles
LOCK_HOOKS_DIR      = False          # True: el usuario queda con solo lectura en hooks\ (no edita script/politica)

REQUIRED_IN_PACKAGE = ("install.ps1", "windsurf_audit.ps1", "policy.json")
LOG_PATH       = os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), "WindsurfAudit", "install.log")
LOG_MAX_BYTES  = 200 * 1024
LOG_KEEP_LINES = 200
DOWNLOAD_TIMEOUT   = 60              # solo para el respaldo por zip
DOWNLOAD_MAX_BYTES = 100 * 1024 * 1024
INSTALL_TIMEOUT    = 180            # segundos por usuario
SKIP_PROFILES  = {"public", "default", "default user", "all users", "defaultuser0"}
# =================================================================

_PAT = re.compile("|".join(re.escape(p) for p in APP_PATTERNS), re.I)


# ---------------------------- log ----------------------------
def _utc():
    return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


def _trim_log(path):
    try:
        if os.path.getsize(path) > LOG_MAX_BYTES:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()[-LOG_KEEP_LINES:]
            with open(path, "w", encoding="utf-8") as f:
                f.writelines(lines)
    except OSError:
        pass


def log(level, msg, path=None):
    path = path or LOG_PATH
    line = "%s | %s | %s | %s" % (_utc(), socket.gethostname(), level, msg)
    print(line)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        _trim_log(path)
        with open(path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception as e:      # el log nunca debe romper la instalacion
        print("(no se pudo escribir el log: %s)" % e)


# ------------------------- deteccion -------------------------
def _scan_children(directory):
    """Subcarpetas de `directory` cuyo nombre coincide con los patrones."""
    found = []
    try:
        for name in os.listdir(directory):
            full = os.path.join(directory, name)
            if _PAT.search(name) and os.path.isdir(full):
                found.append(full)
    except OSError:
        pass
    return found


def human_profiles(users_root=None):
    """Perfiles de usuarios reales: [(nombre, ruta, sid_o_None)]."""
    out = []
    if winreg is not None and users_root is None:
        base = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList"
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base) as k:
                for i in range(winreg.QueryInfoKey(k)[0]):
                    sid = winreg.EnumKey(k, i)
                    # S-1-5-21: cuentas locales/dominio; S-1-12-1: Azure AD. Se omiten las del sistema.
                    if not (sid.startswith("S-1-5-21-") or sid.startswith("S-1-12-1-")):
                        continue
                    try:
                        with winreg.OpenKey(k, sid) as sk:
                            path = os.path.expandvars(winreg.QueryValueEx(sk, "ProfileImagePath")[0])
                    except OSError:
                        continue
                    name = os.path.basename(path.rstrip("\\/"))
                    if os.path.isdir(path) and name.lower() not in SKIP_PROFILES:
                        out.append((name, path, sid))
        except OSError:
            pass
        if out:
            return out
    root = users_root or (os.environ.get("SystemDrive", "C:") + "\\Users")
    try:
        for name in sorted(os.listdir(root)):
            path = os.path.join(root, name)
            if os.path.isdir(path) and name.lower() not in SKIP_PROFILES:
                out.append((name, path, None))
    except OSError:
        pass
    return out


def _registry_matches_loaded_users():
    """{sid: [DisplayName...]} para usuarios con sesion cargada (instalaciones por usuario)."""
    res = {}
    if winreg is None:
        return res
    sub = r"Software\Microsoft\Windows\CurrentVersion\Uninstall"
    try:
        with winreg.OpenKey(winreg.HKEY_USERS, "") as hu:
            sids = [winreg.EnumKey(hu, i) for i in range(winreg.QueryInfoKey(hu)[0])]
    except OSError:
        return res
    for sid in sids:
        if sid.endswith("_Classes"):
            continue
        try:
            with winreg.OpenKey(winreg.HKEY_USERS, sid + "\\" + sub) as key:
                for i in range(winreg.QueryInfoKey(key)[0]):
                    try:
                        with winreg.OpenKey(key, winreg.EnumKey(key, i)) as sk:
                            dn = str(winreg.QueryValueEx(sk, "DisplayName")[0])
                    except OSError:
                        continue
                    if _PAT.search(dn):
                        res.setdefault(sid, []).append(dn)
        except OSError:
            continue
    return res


def profile_evidence(profile, sid=None, reg_by_sid=None):
    ev = []
    ev += _scan_children(os.path.join(profile, "AppData", "Local", "Programs"))
    ev += _scan_children(os.path.join(profile, "AppData", "Roaming"))
    cw = os.path.join(profile, ".codeium", "windsurf")
    if os.path.isdir(cw):
        try:
            # hooks.json* lo crea el instalador: no cuenta como prueba de que Windsurf exista
            others = [n for n in os.listdir(cw) if not n.lower().startswith("hooks.json")]
        except OSError:
            others = []
        if others:
            ev.append(cw)
    if sid and reg_by_sid and sid in reg_by_sid:
        ev += ["registro: " + n for n in reg_by_sid[sid]]
    return ev


def machine_evidence(program_dirs=None):
    ev = []
    dirs = program_dirs if program_dirs is not None else [
        os.environ.get("ProgramFiles", r"C:\Program Files"),
        os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")]
    for d in dirs:
        ev += _scan_children(d)
    if winreg is not None and program_dirs is None:
        for p in (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                  r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"):
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, p) as key:
                    for i in range(winreg.QueryInfoKey(key)[0]):
                        try:
                            with winreg.OpenKey(key, winreg.EnumKey(key, i)) as sk:
                                dn = str(winreg.QueryValueEx(sk, "DisplayName")[0])
                        except OSError:
                            continue
                        if _PAT.search(dn):
                            ev.append("registro del equipo: " + dn)
            except OSError:
                continue
    return ev


def detect_targets(users_root=None, program_dirs=None):
    """Devuelve (lista de (nombre, ruta, sid), evidencia_por_nombre, evidencia_de_equipo)."""
    profiles = human_profiles(users_root)
    reg = _registry_matches_loaded_users()
    per_user, targets = {}, []
    for name, path, sid in profiles:
        ev = profile_evidence(path, sid, reg)
        if ev:
            targets.append((name, path, sid))
            per_user[name] = ev
    mach = machine_evidence(program_dirs)
    if not targets and mach and INSTALL_ALL_IF_MACHINE_WIDE:
        targets = list(profiles)          # instalado para todo el equipo: todos los perfiles
    return targets, per_user, mach


# ------------------------- modo piloto -------------------------
def local_ips():
    """IPv4 del equipo (sin loopback). No envia ningun paquete."""
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("203.0.113.1", 9))     # solo elige la interfaz de salida; UDP no envia nada al conectar
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    return sorted(i for i in ips if not i.startswith("127.") and i != "0.0.0.0")


def parse_list(value):
    return [x for x in re.split(r"[,\s;]+", value or "") if x]


def matching_ips(ips, specs):
    """IPs del equipo que coinciden con alguna IP o CIDR de `specs`."""
    nets = []
    for spec in specs:
        try:
            nets.append(ipaddress.ip_network(spec, strict=False))
        except ValueError:
            raise RuntimeError("only_ips invalido: '%s' (usa 10.1.2.3 o 10.1.2.0/24)" % spec)
    return [ip for ip in ips if any(ipaddress.ip_address(ip) in n for n in nets)]


def validate_siem(ip, port):
    """Valida siem_ip / siem_port con mensajes claros (se llama ANTES de descargar nada)."""
    try:
        ipaddress.IPv4Address(ip)
    except ValueError:
        raise RuntimeError("siem_ip invalido: '%s' (debe ser una IPv4, por ejemplo 10.20.30.40)" % ip)
    if port:
        try:
            n = int(port)
        except ValueError:
            raise RuntimeError("siem_port invalido: '%s' (debe ser un numero)" % port)
        if not 1 <= n <= 65535:
            raise RuntimeError("siem_port fuera de rango: %s" % port)


def patch_siem(script_path, ip, port):
    """SOLO PRUEBAS: cambia el destino syslog en la copia extraida de windsurf_audit.ps1."""
    validate_siem(ip, port)
    with open(script_path, "r", encoding="utf-8", newline="") as f:
        txt = f.read()
    txt, n = re.subn(r'(\$SYSLOG_HOST\s*=\s*")[^"]*(")', lambda m: m.group(1) + ip + m.group(2), txt, count=1)
    if n != 1:
        raise RuntimeError("no se encontro $SYSLOG_HOST en windsurf_audit.ps1")
    if port:
        port = int(port)
        txt, n = re.subn(r"(\$SYSLOG_PORT\s*=\s*)\d+", lambda m: m.group(1) + str(port), txt, count=1)
        if n != 1:
            raise RuntimeError("no se encontro $SYSLOG_PORT en windsurf_audit.ps1")
    with open(script_path, "w", encoding="utf-8", newline="") as f:
        f.write(txt)


# ------------------- obtener el repo (publico) -------------------
_REPO_RE = re.compile(r"^(?:https://github\.com/)?([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+?)(?:\.git)?/?$")
_NOWIN = 0x08000000 if os.name == "nt" else 0      # CREATE_NO_WINDOW


def repo_parts(repo):
    """('organizacion', 'repositorio'). Solo se aceptan repos de github.com."""
    m = _REPO_RE.match((repo or "").strip())
    if not m:
        raise RuntimeError("repo invalido: '%s' (usa 'organizacion/repositorio' o "
                           "https://github.com/organizacion/repositorio)" % repo)
    return m.group(1), m.group(2)


def clone_url(repo):
    owner, name = repo_parts(repo)
    return "https://github.com/%s/%s.git" % (owner, name)


def valid_ref(ref):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/-]*", ref or ""):
        raise RuntimeError("ref invalido: '%s' (rama, tag o SHA de commit)" % ref)
    return ref


def find_git(profiles=()):
    """git.exe en el PATH, en Program Files o en la instalacion por usuario de los perfiles destino."""
    found = shutil.which("git")
    if found:
        return found
    cands = []
    for var in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)"):
        base = os.environ.get(var)
        if base:
            cands += [os.path.join(base, "Git", "cmd", "git.exe"), os.path.join(base, "Git", "bin", "git.exe")]
    for prof in profiles:
        cands.append(os.path.join(prof, "AppData", "Local", "Programs", "Git", "cmd", "git.exe"))
    for c in cands:
        if os.path.isfile(c):
            return c
    return None


def git_clone(git_exe, url, ref, dest, timeout):
    """Clona `ref` (rama, tag o SHA de 40 hex) en `dest`. Devuelve el SHA del commit clonado."""
    env = os.environ.copy()
    env["GIT_TERMINAL_PROMPT"] = "0"          # nunca pedir usuario/clave (es un repo publico)
    env["GCM_INTERACTIVE"] = "never"          # Git Credential Manager: sin ventanas
    base = [git_exe, "-c", "credential.helper="]

    def git(args, cwd=None):
        try:
            p = subprocess.run(base + args, cwd=cwd, env=env, capture_output=True, text=True,
                               errors="replace", timeout=timeout, creationflags=_NOWIN)
        except subprocess.TimeoutExpired:
            raise RuntimeError("git %s tardo mas de %d s" % (args[0], timeout))
        if p.returncode != 0:
            raise RuntimeError("git %s fallo (codigo %d): %s" % (args[0], p.returncode, _tail(p.stderr or p.stdout)))
        return p.stdout

    if re.fullmatch(r"[0-9a-fA-F]{40}", ref):         # commit exacto
        os.makedirs(dest)
        git(["init", "-q"], dest)
        git(["remote", "add", "origin", url], dest)
        git(["fetch", "-q", "--depth", "1", "origin", ref], dest)
        git(["checkout", "-q", "FETCH_HEAD"], dest)
    else:                                              # rama o tag
        git(["clone", "-q", "--depth", "1", "--branch", ref, url, dest])
    return git(["rev-parse", "HEAD"], dest).strip()


def download(url, dest):
    """Solo para el respaldo por zip publico (FALLBACK_ZIP_IF_NO_GIT)."""
    req = urllib.request.Request(url, headers={"User-Agent": "windsurf-audit-installer"})
    total = 0
    with urllib.request.urlopen(req, timeout=DOWNLOAD_TIMEOUT) as r, open(dest, "wb") as f:
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            total += len(chunk)
            if total > DOWNLOAD_MAX_BYTES:
                raise RuntimeError("la descarga supera el tope de %d bytes" % DOWNLOAD_MAX_BYTES)
            f.write(chunk)
    return total


def obtain_repo(cfg, tmp, profiles, lp):
    """Deja el repo en tmp\\repo. Primero git clone; el zip publico solo si se habilito el respaldo."""
    dest = os.path.join(tmp, "repo")
    ref = valid_ref(cfg["ref"])
    url = cfg.get("clone_url") or clone_url(cfg["repo"])
    git = cfg.get("git_exe") or find_git(profiles)
    if git:
        commit = git_clone(git, url, ref, dest, cfg.get("git_timeout", GIT_TIMEOUT))
        log("INFO", "repo clonado | %s | ref=%s | commit=%s" % (url, ref, commit), lp)
        return dest
    if cfg.get("fallback_zip", FALLBACK_ZIP_IF_NO_GIT):
        owner, name = repo_parts(cfg["repo"])
        zurl = cfg.get("zip_url") or "https://github.com/%s/%s/archive/%s.zip" % (owner, name, ref)
        zpath = os.path.join(tmp, "repo.zip")
        size = download(zurl, zpath)
        safe_extract(zpath, dest)
        log("WARN", "git NO esta instalado: se descargo el zip publico (%d bytes) en vez de clonar" % size, lp)
        return dest
    raise RuntimeError("git no esta instalado en este equipo (no esta en el PATH ni en Program Files\\Git); "
                       "no se pudo clonar. Instala Git o activa FALLBACK_ZIP_IF_NO_GIT")


def _rm_readonly(func, path, _exc):
    try:
        os.chmod(path, stat.S_IWRITE)      # los archivos de .git son de solo lectura en Windows
        func(path)
    except OSError:
        pass


def cleanup(path):
    try:
        shutil.rmtree(path, onexc=_rm_readonly)      # Python 3.12+
    except TypeError:
        shutil.rmtree(path, onerror=_rm_readonly)


def safe_extract(zip_path, dest):
    """Extrae rechazando rutas que se salgan de `dest` (zip-slip)."""
    os.makedirs(dest, exist_ok=True)
    base = os.path.realpath(dest)
    with zipfile.ZipFile(zip_path) as z:
        for m in z.infolist():
            target = os.path.realpath(os.path.join(dest, m.filename))
            if target != base and not target.startswith(base + os.sep):
                raise RuntimeError("zip con ruta sospechosa: %s" % m.filename)
        z.extractall(dest)


def find_file(root, filename):
    """Primera ruta de un archivo llamado `filename` (sin distinguir mayusculas)."""
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d != ".git"]
        for f in files:
            if f.lower() == filename.lower():
                return os.path.join(dirpath, f)
    return None


def find_package_dir(root):
    """Carpeta que contiene install.ps1, windsurf_audit.ps1 y policy.json juntos."""
    for dirpath, _dirs, files in os.walk(root):
        if all(f in files for f in REQUIRED_IN_PACKAGE):
            return dirpath
    return None


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# --------------------------- instalacion ---------------------------
def _powershell_exe():
    root = os.environ.get("SystemRoot", r"C:\Windows")
    p = os.path.join(root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
    return p if os.path.isfile(p) else "powershell"


def _tail(text, n=3, width=160):
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    return " / ".join(l[:width] for l in lines[-n:])


def run_installer(name, profile, pkg_dir, ps_exe, skip_test, timeout):
    """Ejecuta install.ps1 con el perfil del usuario destino. Devuelve (ok, detalle)."""
    cmd = [ps_exe, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
           "-File", os.path.join(pkg_dir, "install.ps1")]
    if skip_test:
        cmd.append("-SkipTest")
    env = os.environ.copy()
    env["USERPROFILE"] = profile      # install.ps1 usa $env:USERPROFILE para todas sus rutas
    env["USERNAME"] = name            # el evento de prueba lleva este usuario
    flags = 0x08000000 if os.name == "nt" else 0     # CREATE_NO_WINDOW
    try:
        p = subprocess.run(cmd, cwd=pkg_dir, env=env, capture_output=True, text=True,
                           errors="replace", timeout=timeout, creationflags=flags)
    except subprocess.TimeoutExpired:
        return False, "tiempo agotado (%d s)" % timeout
    except OSError as e:
        return False, "no se pudo ejecutar PowerShell: %s" % e
    detalle = _tail(p.stdout) if p.returncode == 0 else _tail(p.stderr or p.stdout)
    if p.returncode != 0:
        return False, "install.ps1 termino con codigo %d: %s" % (p.returncode, detalle)
    # comprobacion defensiva: que de verdad haya quedado instalado
    must = (os.path.join(profile, "hooks", "windsurf_audit.ps1"),
            os.path.join(profile, ".codeium", "windsurf", "hooks.json"))
    missing = [m for m in must if not os.path.isfile(m)]
    if missing:
        return False, "install.ps1 termino sin error pero falta: %s" % ", ".join(missing)
    return True, detalle


def fix_permissions(profile, sid, lock):
    """Solo Windows y si se conoce el SID. Devuelve nota breve."""
    if os.name != "nt" or not sid:
        return ""
    notes = []
    audit = os.path.join(profile, "windsurf-audit")
    if os.path.isdir(audit):     # el usuario debe poder escribir sus logs aunque los creara SYSTEM
        subprocess.run(["icacls", audit, "/grant", "*%s:(OI)(CI)M" % sid, "/T", "/C"],
                       capture_output=True)
        notes.append("logs: el usuario puede escribir")
    hooks = os.path.join(profile, "hooks")
    if lock and os.path.isdir(hooks):
        subprocess.run(["icacls", hooks, "/inheritance:r"], capture_output=True)
        subprocess.run(["icacls", hooks, "/grant:r", "*S-1-5-18:(OI)(CI)F", "*S-1-5-32-544:(OI)(CI)F",
                        "*%s:(OI)(CI)RX" % sid], capture_output=True)
        notes.append("hooks\\ en solo lectura para el usuario")
    return "; ".join(notes)


def windsurf_running():
    if os.name != "nt":
        return False
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Windsurf.exe"],
                           capture_output=True, text=True, timeout=20)
        return "windsurf.exe" in r.stdout.lower()
    except Exception:
        return False


# ----------------------------- flujo -----------------------------
def main_flow(cfg):
    lp = cfg.get("log_path")
    log("INFO", "inicio | repo=%s ref=%s dry_run=%s skip_test=%s only_ips=%s siem_ip=%s" % (
        cfg["repo"], cfg["ref"], cfg["dry_run"], cfg["skip_test"],
        ",".join(cfg.get("only_ips") or []) or "-", cfg.get("siem_ip") or "-"), lp)

    if os.name != "nt" and not cfg.get("allow_non_windows"):
        log("ABORT", "el equipo no es Windows; no se instalo nada", lp)
        return "ABORT: el equipo no es Windows"

    # ---- 0. modo piloto: solo equipos con las IP indicadas ----
    if cfg.get("only_ips"):
        mine = cfg.get("local_ips_override") or local_ips()
        hit = matching_ips(mine, cfg["only_ips"])
        if not hit:
            log("SKIP", "piloto: este equipo (ips=%s) no esta en only_ips=%s; no se hizo nada" % (
                ",".join(mine) or "?", ",".join(cfg["only_ips"])), lp)
            return "SKIP: este equipo no esta en la lista de piloto (only_ips)"
        log("INFO", "piloto: este equipo coincide con only_ips (%s)" % ",".join(hit), lp)

    if cfg.get("siem_ip"):
        validate_siem(cfg["siem_ip"], cfg.get("siem_port"))      # falla pronto, antes de descargar

    # ---- 1. quien tiene Windsurf/Devin? ----
    targets, per_user, mach = detect_targets(cfg.get("users_root"), cfg.get("program_dirs"))
    if not targets:
        log("ABORT", "el equipo NO tenia Windsurf/Devin (buscado: %s en perfiles y en el equipo); "
                     "no se descargo ni se instalo nada" % ", ".join(APP_PATTERNS), lp)
        return "ABORT: el equipo no tenia Windsurf/Devin; no se instalo nada"
    log("INFO", "Windsurf/Devin detectado | usuarios=%s | equipo=%s" % (
        ", ".join(n for n, _p, _s in targets), "; ".join(mach)[:120] or "no"), lp)

    if cfg["repo"] in ("", "OWNER/REPO") and not cfg.get("clone_url"):
        raise RuntimeError("configura GITHUB_REPO (o pasa el parametro repo)")
    if not cfg.get("clone_url"):
        repo_parts(cfg["repo"])                      # valida el formato antes de hacer nada

    tmp = tempfile.mkdtemp(prefix="wsa_")
    try:
        # ---- 2. clonar el repo publico ----
        repo_dir = obtain_repo(cfg, tmp, [pp for _n, pp, _s in targets], lp)

        # ---- 3. localizar y descomprimir el paquete ----
        pkg_zip = find_file(repo_dir, cfg["zip_name"])
        if not pkg_zip:
            raise RuntimeError("el repo no contiene %s" % cfg["zip_name"])
        got = sha256_file(pkg_zip)
        if cfg["expected_zip_sha256"]:
            if got.lower() != cfg["expected_zip_sha256"].lower():
                raise RuntimeError("SHA-256 de %s NO coincide (esperado %s, obtenido %s)"
                                   % (cfg["zip_name"], cfg["expected_zip_sha256"], got))
            log("INFO", "SHA-256 del paquete verificado: %s" % got, lp)
        else:
            log("WARN", "sin EXPECTED_ZIP_SHA256: no se verifico la integridad (SHA-256 del paquete: %s)" % got, lp)
        pkg_root = os.path.join(tmp, "pkg")
        safe_extract(pkg_zip, pkg_root)
        pkg_dir = find_package_dir(pkg_root)
        if not pkg_dir:
            raise RuntimeError("el paquete no contiene %s juntos en una misma carpeta"
                               % ", ".join(REQUIRED_IN_PACKAGE))
        log("INFO", "paquete listo: %s" % ", ".join(sorted(os.listdir(pkg_dir))), lp)
        if cfg.get("siem_ip"):
            patch_siem(os.path.join(pkg_dir, "windsurf_audit.ps1"), cfg["siem_ip"], cfg.get("siem_port"))
            log("WARN", "SIEM SOBRESCRITO a %s:%s (SOLO PRUEBAS: los eventos NO iran al Exabeam de produccion)" % (
                cfg["siem_ip"], cfg.get("siem_port") or "puerto del paquete"), lp)

        # ---- 4. ejecutar el instalador por usuario ----
        ps_exe = cfg.get("powershell_exe") or _powershell_exe()
        results, errors = [], 0
        for name, path, sid in targets:
            if cfg["dry_run"]:
                results.append("%s: [dry-run] se ejecutaria install.ps1 con USERPROFILE=%s" % (name, path))
                continue
            ok, detalle = run_installer(name, path, pkg_dir, ps_exe, cfg["skip_test"],
                                        cfg.get("install_timeout", INSTALL_TIMEOUT))
            if ok:
                nota = fix_permissions(path, sid, cfg.get("lock_hooks", LOCK_HOOKS_DIR))
                results.append("%s: OK%s" % (name, (" (" + nota + ")") if nota else ""))
            else:
                errors += 1
                results.append("%s: ERROR %s" % (name, detalle))
        summary = " || ".join(results)
        if not cfg["dry_run"] and windsurf_running():
            summary += " || Windsurf esta abierto: el usuario debe reiniciarlo para activar los hooks"
        log("ERROR" if errors else "OK", "instalacion terminada | %s" % summary, lp)
        if errors:
            raise RuntimeError(summary)
        return "OK: " + summary
    finally:
        cleanup(tmp)


def _truthy(v):
    return str(v).strip().lower() in ("1", "true", "si", "yes", "y")


def run(repo=None, ref=None, expected_zip_sha256=None, dry_run=None, skip_test=None,
        only_ips=None, siem_ip=None, siem_port=None):
    cfg = {
        "repo": (repo or GITHUB_REPO).strip(),
        "ref": (ref or GITHUB_REF).strip(),
        "zip_name": ZIP_NAME,
        "expected_zip_sha256": (expected_zip_sha256 or EXPECTED_ZIP_SHA256).strip(),
        "dry_run": _truthy(dry_run) if dry_run is not None else False,
        "skip_test": _truthy(skip_test) if skip_test is not None else SKIP_TEST,
        "only_ips": parse_list(only_ips if only_ips is not None else ONLY_IPS),
        "siem_ip": str(siem_ip if siem_ip is not None else SIEM_IP_OVERRIDE).strip(),
        "siem_port": str(siem_port if siem_port is not None else SIEM_PORT_OVERRIDE).strip(),
    }
    try:
        return main_flow(cfg)
    except Exception as e:
        log("ERROR", "fallo: %s" % e)
        raise


if __name__ == "__main__":
    print(run(*sys.argv[1:9]))
