# -*- coding: utf-8 -*-
"""
construir_paquete.py
Reconstruye paquete/windsurf_audit_windows.zip a partir de fuente/ y actualiza SHA256.txt.
El zip es REPRODUCIBLE: los mismos archivos dan siempre el mismo SHA-256 (fechas fijas, orden fijo).

Uso (desde la raiz del repo):   python construir_paquete.py
Despues de ejecutarlo: commit, tag nuevo y copiar el SHA-256 de SHA256.txt a EXPECTED_ZIP_SHA256 (Cortex).
"""
import hashlib
import os
import sys
import zipfile

RAIZ = os.path.dirname(os.path.abspath(__file__))
FUENTE = os.path.join(RAIZ, "fuente")
DESTINO = os.path.join(RAIZ, "paquete", "windsurf_audit_windows.zip")
OBLIGATORIOS = ["install.ps1", "windsurf_audit.ps1", "policy.json"]
ARCHIVOS = ["install.ps1", "windsurf_audit.ps1", "policy.json", "ver_logs.ps1", "diagnostico_siem.ps1"]
FECHA_FIJA = (2026, 1, 1, 0, 0, 0)

faltan = [f for f in OBLIGATORIOS if not os.path.isfile(os.path.join(FUENTE, f))]
if faltan:
    sys.exit("Faltan en fuente/: " + ", ".join(faltan))

os.makedirs(os.path.dirname(DESTINO), exist_ok=True)
with zipfile.ZipFile(DESTINO, "w", zipfile.ZIP_DEFLATED) as z:
    for nombre in ARCHIVOS:
        ruta = os.path.join(FUENTE, nombre)
        if not os.path.isfile(ruta):
            print("(aviso) no existe fuente/%s: se omite" % nombre)
            continue
        info = zipfile.ZipInfo(nombre, date_time=FECHA_FIJA)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        with open(ruta, "rb") as f:
            z.writestr(info, f.read())

h = hashlib.sha256(open(DESTINO, "rb").read()).hexdigest()
with open(os.path.join(RAIZ, "SHA256.txt"), "w", encoding="ascii") as f:
    f.write("%s  paquete/windsurf_audit_windows.zip\n" % h)
print("Paquete: %s" % DESTINO)
print("SHA-256: %s" % h)
