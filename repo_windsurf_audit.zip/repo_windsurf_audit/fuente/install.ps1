#Requires -Version 5.1
<#
  install.ps1 - Instalador de Windsurf Audit Hook (v3)

  Uso (desde PowerShell, en la carpeta donde estan los archivos):
      powershell -ExecutionPolicy Bypass -File .\install.ps1
      powershell -ExecutionPolicy Bypass -File .\install.ps1 -SkipTest   # sin evento de prueba

  Hace:
    1. Crea  %USERPROFILE%\hooks, %USERPROFILE%\windsurf-audit y %USERPROFILE%\.codeium\windsurf
    2. Copia windsurf_audit.ps1, policy.json y ver_logs.ps1 a %USERPROFILE%\hooks
    3. Genera %USERPROFILE%\.codeium\windsurf\hooks.json con la ruta real del usuario
       (si ya existe, guarda una copia .bak)
    4. Envia un evento de prueba (tambien llega a Exabeam) y muestra la ultima linea del log
#>
param([switch]$SkipTest)

$ErrorActionPreference = "Stop"
$src      = $PSScriptRoot
$hooksDir = Join-Path $env:USERPROFILE "hooks"
$auditDir = Join-Path $env:USERPROFILE "windsurf-audit"
$wsDir    = Join-Path $env:USERPROFILE ".codeium\windsurf"
$script   = Join-Path $hooksDir "windsurf_audit.ps1"
$hooksCfg = Join-Path $wsDir "hooks.json"

foreach ($f in "windsurf_audit.ps1", "policy.json") {
    if (-not (Test-Path (Join-Path $src $f))) { throw "Falta el archivo $f junto a install.ps1" }
}

Write-Host "[1/4] Creando carpetas..."
foreach ($d in $hooksDir, $auditDir, $wsDir) { New-Item -ItemType Directory -Force -Path $d | Out-Null }

Write-Host "[2/4] Copiando archivos a $hooksDir ..."
Copy-Item (Join-Path $src "windsurf_audit.ps1") $script -Force
Copy-Item (Join-Path $src "policy.json") (Join-Path $hooksDir "policy.json") -Force
foreach ($extra in "ver_logs.ps1", "diagnostico_siem.ps1") {
    if (Test-Path (Join-Path $src $extra)) {
        Copy-Item (Join-Path $src $extra) (Join-Path $hooksDir $extra) -Force
    }
}
Unblock-File -Path $script -ErrorAction SilentlyContinue

Write-Host "[3/4] Generando hooks.json ..."
if (Test-Path $hooksCfg) {
    $bak = "$hooksCfg.{0}.bak" -f (Get-Date -Format "yyyyMMdd-HHmmss")
    Copy-Item $hooksCfg $bak -Force
    Write-Host "      (respaldo del hooks.json anterior: $bak)"
}
$cmd = "powershell -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$script`""
$hookNames = "pre_user_prompt", "pre_run_command", "pre_read_code", "pre_write_code", "pre_mcp_tool_use", "post_cascade_response"
$hooks = [ordered]@{}
foreach ($h in $hookNames) {
    $hooks[$h] = @( [ordered]@{ command = $cmd; show_output = $false } )
}
$json = ([ordered]@{ hooks = $hooks } | ConvertTo-Json -Depth 6)
# UTF-8 sin BOM (algunos parsers JSON fallan con BOM)
[System.IO.File]::WriteAllText($hooksCfg, $json, [System.Text.UTF8Encoding]::new($false))

if (-not $SkipTest) {
    Write-Host "[4/4] Evento de prueba..."
    $sample = '{"agent_action_name":"pre_user_prompt","trajectory_id":"install-test","execution_id":"install-test","tool_info":{"user_prompt":"prueba de instalacion"}}'
    $sample | powershell -NoProfile -ExecutionPolicy Bypass -File $script
    $log = Join-Path $auditDir "audit.jsonl"
    if (Test-Path $log) {
        Write-Host "      Ultima linea de audit.jsonl:"
        Get-Content $log -Tail 1
    } else {
        Write-Warning "No se creo audit.jsonl. Revisa $auditDir\errors.log"
    }
} else {
    Write-Host "[4/4] Prueba omitida (-SkipTest)."
}

Write-Host ""
Write-Host "Listo. Cierra y vuelve a abrir Windsurf por completo."
Write-Host "Para ver eventos en vivo:  Get-Content `"$auditDir\audit.jsonl`" -Wait"
Write-Host "Ver el log ordenado:       powershell -ExecutionPolicy Bypass -File `"$hooksDir\ver_logs.ps1`""
Write-Host "Si algo falla, revisa:     $auditDir\errors.log"
