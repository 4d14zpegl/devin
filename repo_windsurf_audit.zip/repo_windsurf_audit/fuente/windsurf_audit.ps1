#Requires -Version 5.1
<#
  windsurf_audit.ps1 - v3  (visibilidad + control)

  - Registra prompts, respuestas, comandos, lectura/escritura de archivos y uso de MCP.
  - Evalua politicas (policy.json, junto a este script) en los hooks pre_* y puede BLOQUEAR
    la accion (exit 2 + mensaje por stderr).
  - Destinos: log local JSONL + SIEM Exabeam (Syslog RFC 5424, UDP o TCP).
  - Verifica conectividad con el SIEM (con cache) y, si no hay, encola los eventos en
    siem-spool.jsonl y los reenvia cuando vuelva la conexion. Bloqueo opcional si no hay SIEM.

  Modos (policy.json -> "mode"):
    "audit"   : solo registra; lo que se habria bloqueado queda como WOULD_BLOCK.
    "enforce" : bloquea de verdad.
  Si policy.json no existe o esta corrupto, el script funciona en solo-auditoria.

  Archivo en ASCII puro a proposito (PowerShell 5.1 lee mal UTF-8 sin BOM).
#>

# ======================== CONFIG ========================
$SYSLOG_HOST   = "192.168.52.49"
$SYSLOG_PORT   = 514
$SEND_TO_SIEM  = $true

# --- Formato hacia el SIEM ---
# "legacy"   = IDENTICO al script original: 1 datagrama por evento, mismos campos y orden, PRI 14;
#              hora de cabecera = hora del equipo (UTC, valida en RFC 5424). Es lo que el parser/reglas de Exabeam ya conocen.
# "extended" = campos extra (event_id, decision, rule_ids, ...) y contenido fragmentado.
#              Requiere que Exabeam tenga un parser para ese formato.
$SIEM_FORMAT      = "legacy"
# Tipos de evento que se envian al SIEM (todos se guardan siempre en el log local).
# Opciones: USER_PROMPT, AGENT_RESPONSE, COMMAND_EXEC, FILE_READ, FILE_WRITE, MCP_TOOL_USE
$SIEM_EVENT_TYPES = @("USER_PROMPT", "AGENT_RESPONSE")
$LEGACY_MAX_BYTES = 60000   # tope de un datagrama UDP (max. teorico 65507); si se pasa, se recorta el contenido

# --- Conectividad con el SIEM ---
$SIEM_PROTOCOL         = "udp"   # "udp" | "tcp"  (tcp solo si Exabeam tiene listener TCP en ese puerto)
$SIEM_CHECK            = $true   # verificar conectividad antes de enviar
$SIEM_CHECK_TIMEOUT_MS = 1500    # timeout de la verificacion / conexion TCP
$SIEM_CHECK_CACHE_SEC  = 30      # no re-verificar mas de una vez cada N segundos (evita latencia)
$BLOCK_IF_SIEM_DOWN    = $false  # $true = bloquear acciones pre_* si no hay SIEM
                                 # (solo surte efecto si $ALLOW_BLOCKING tambien es $true)
$SPOOL_MAX_BYTES       = 5MB     # tope de la cola local de eventos pendientes
$SPOOL_FLUSH_MAX       = 200     # mensajes que se reenvian por ejecucion

$LOG_DIR       = Join-Path $env:USERPROFILE "windsurf-audit"
$LOG_FILE      = Join-Path $LOG_DIR "audit.jsonl"
$ERR_FILE      = Join-Path $LOG_DIR "errors.log"
$POLICY_FILE   = Join-Path $PSScriptRoot "policy.json"
$SPOOL_FILE    = Join-Path $LOG_DIR "siem-spool.jsonl"
$STATUS_FILE   = Join-Path $LOG_DIR "siem-status.json"
$MAX_LOG_BYTES = 50MB
$MAX_LOG_FILES = 10

$CHUNK_CHARS   = 500      # con ~500 bytes de metadatos, cada datagrama queda cerca de 1 KB
$MAX_CHUNKS    = 40

$REDACT_SIEM   = $true
$REDACT_LOCAL  = $true    # true por defecto: un prompt bloqueado por contener un secreto
                          # no debe quedar en claro en el log. content_sha256 permite verificar.

# Que hacer si el script falla en un hook pre_*:
#   $false = fail-open  (el usuario sigue trabajando, queda en errors.log)
#   $true  = fail-closed (se bloquea la accion; mas estricto, mas friccion)
$FAIL_CLOSED   = $false

# INTERRUPTOR MAESTRO: mientras sea $false, el script NUNCA bloquea nada (siempre exit 0),
# sin importar lo que diga policy.json. Las reglas siguen evaluandose y quedan como
# WOULD_BLOCK / FLAGGED en el log y en Exabeam (visibilidad sin friccion).
$ALLOW_BLOCKING = $false
# ========================================================

$ErrorActionPreference = "Stop"

# ---------- utilidades ----------
function Write-ErrLog([string]$msg) {
    try {
        $line = "{0} {1}" -f (Get-Date -Format "o"), $msg
        [System.IO.File]::AppendAllText($ERR_FILE, $line + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
    } catch { }
}

# Modo traza (apagado por defecto): se activa con $env:WSA_DEBUG = "1" o creando el archivo
# windsurf-audit\debug.flag (asi se captura lo que hace el hook cuando lo ejecuta Windsurf).
# Guarda cada paso en debug.log. Contiene texto de prompts: borrar flag y log al terminar.
$TRACE = (($env:WSA_DEBUG -eq "1") -or (Test-Path (Join-Path $LOG_DIR "debug.flag")))
function Write-Trace([string]$m) {
    if (-not $TRACE) { return }
    Write-Host ("[trace] " + $m)
    try {
        $line = "{0} [pid {1}] {2}" -f (Get-Date -Format "o"), $PID, $m
        [System.IO.File]::AppendAllText((Join-Path $LOG_DIR "debug.log"), $line + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
    } catch { }
}

function ConvertTo-IsoUtc($ts) {
    try {
        if ($ts) { return ([datetime]::Parse([string]$ts)).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ") }
    } catch { }
    return (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
}

function ConvertTo-JsonString([string]$s) {
    if ($null -eq $s) { return '""' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('"')
    foreach ($c in $s.ToCharArray()) {
        switch ($c) {
            '"'     { [void]$sb.Append('\"') }
            '\'     { [void]$sb.Append('\\') }
            "`n"    { [void]$sb.Append('\n') }
            "`r"    { [void]$sb.Append('\r') }
            "`t"    { [void]$sb.Append('\t') }
            default {
                if ([int]$c -lt 32) { [void]$sb.AppendFormat('\u{0:x4}', [int]$c) }
                else { [void]$sb.Append($c) }
            }
        }
    }
    [void]$sb.Append('"')
    return $sb.ToString()
}

function Get-Sha256([string]$s) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $h = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($s))
        return ([BitConverter]::ToString($h) -replace '-', '').ToLower()
    } finally { $sha.Dispose() }
}

# Patrones de redaccion (independientes de las reglas de bloqueo de policy.json)
$SECRET_PATTERNS = @(
    '-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----',
    'AKIA[0-9A-Z]{16}',
    'gh[pousr]_[A-Za-z0-9]{36,}',
    'xox[baprs]-[A-Za-z0-9-]{10,}',
    'sk-[A-Za-z0-9_-]{20,}',
    'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}',
    '(?i)bearer\s+[A-Za-z0-9._~+/=-]{20,}',
    '(?i)(password|passwd|pwd|secret|token|api[_-]?key)\s*[:=]\s*\S+'
)

function Protect-Secrets([string]$text) {
    $count = 0
    foreach ($p in $SECRET_PATTERNS) {
        $count += [regex]::Matches($text, $p).Count
        $text = [regex]::Replace($text, $p, '[REDACTED]')
    }
    return @{ Text = $text; Count = $count }
}

function Test-Rules([string]$text, $rules) {
    # Devuelve las reglas que coinciden. Timeout de 1s por regla (anti-ReDoS).
    $hits = @()
    foreach ($r in $rules) {
        if (-not $r -or -not $r.pattern) { continue }
        try {
            $re = New-Object System.Text.RegularExpressions.Regex(
                [string]$r.pattern,
                [System.Text.RegularExpressions.RegexOptions]::None,
                [TimeSpan]::FromSeconds(1))
            if ($re.IsMatch($text)) { $hits += $r }
        } catch { Write-ErrLog "regla $($r.id) fallo: $_" }
    }
    return $hits
}

function Write-LocalLog([string]$line) {
    $bytes = [System.Text.UTF8Encoding]::new($false).GetBytes($line + "`n")
    try {
        if ((Test-Path $LOG_FILE) -and ((Get-Item $LOG_FILE).Length -gt $MAX_LOG_BYTES)) {
            $rot = Join-Path $LOG_DIR ("audit-{0}.jsonl" -f (Get-Date -Format "yyyyMMdd-HHmmss"))
            Move-Item -Path $LOG_FILE -Destination $rot -ErrorAction Stop
            Get-ChildItem $LOG_DIR -Filter "audit-*.jsonl" |
                Sort-Object LastWriteTime -Descending |
                Select-Object -Skip $MAX_LOG_FILES |
                Remove-Item -Force -ErrorAction SilentlyContinue
        }
    } catch { }
    for ($i = 1; $i -le 6; $i++) {
        try {
            $fs = [System.IO.File]::Open($LOG_FILE, [System.IO.FileMode]::Append,
                                         [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
            try { $fs.Write($bytes, 0, $bytes.Length) } finally { $fs.Dispose() }
            return $true
        } catch { Start-Sleep -Milliseconds (40 * $i) }
    }
    return $false
}

function Split-Chunks([string]$text, [int]$size) {
    $chunks = New-Object System.Collections.Generic.List[string]
    if ([string]::IsNullOrEmpty($text)) { $chunks.Add(""); return ,$chunks }
    $pos = 0
    while ($pos -lt $text.Length) {
        $len = [Math]::Min($size, $text.Length - $pos)
        if (($pos + $len) -lt $text.Length -and [char]::IsHighSurrogate($text[$pos + $len - 1])) { $len-- }
        $chunks.Add($text.Substring($pos, $len))
        $pos += $len
    }
    return ,$chunks
}

function Connect-Tcp {
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $c.BeginConnect($SYSLOG_HOST, $SYSLOG_PORT, $null, $null)
        if (-not $iar.AsyncWaitHandle.WaitOne($SIEM_CHECK_TIMEOUT_MS)) {
            throw "timeout de conexion TCP ($SIEM_CHECK_TIMEOUT_MS ms)"
        }
        $c.EndConnect($iar)
        return $c
    } catch { $c.Close(); throw }
}

function Send-Siem([string[]]$messages) {
    if ($SIEM_PROTOCOL -eq "tcp") {
        # Syslog sobre TCP con framing por salto de linea (los mensajes no contienen saltos crudos)
        $c = Connect-Tcp
        try {
            $stream = $c.GetStream()
            foreach ($m in $messages) {
                $b = [System.Text.Encoding]::UTF8.GetBytes($m + "`n")
                $stream.Write($b, 0, $b.Length)
            }
            $stream.Flush()
        } finally { $c.Close() }
    } else {
        $udp = New-Object System.Net.Sockets.UdpClient
        try {
            $udp.Connect($SYSLOG_HOST, $SYSLOG_PORT)
            foreach ($m in $messages) {
                $b = [System.Text.Encoding]::UTF8.GetBytes($m)
                $sent = $udp.Send($b, $b.Length)
                Write-Trace "udp: enviados $sent bytes a ${SYSLOG_HOST}:${SYSLOG_PORT} desde $($udp.Client.LocalEndPoint)"
                if ($messages.Count -gt 1) { Start-Sleep -Milliseconds 5 }   # pausa anti-rafaga
            }
        } finally { $udp.Close() }
    }
}

function Get-SiemCache {
    try {
        if (Test-Path $STATUS_FILE) {
            $st  = Get-Content -Raw -Path $STATUS_FILE | ConvertFrom-Json
            $age = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - [int64]$st.t
            if ($age -ge 0 -and $age -lt $SIEM_CHECK_CACHE_SEC) {
                return @{ ok = [bool]$st.ok; reason = [string]$st.reason; cached = $true }
            }
        }
    } catch { }
    return $null
}

function Set-SiemCache([bool]$ok, [string]$reason) {
    try {
        $o = [ordered]@{ t = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds(); ok = $ok; reason = $reason }
        [System.IO.File]::WriteAllText($STATUS_FILE, ($o | ConvertTo-Json -Compress), [System.Text.UTF8Encoding]::new($false))
    } catch { }
}

function Test-Siem {
    # TCP: handshake real (confirma que hay un listener).
    # UDP: envia un latido (HEARTBEAT) y detecta errores locales y respuestas ICMP
    #      (red caida, sin ruta, DNS, puerto inaccesible). UDP NO puede confirmar entrega.
    $cached = Get-SiemCache
    if ($cached) { return $cached }
    $ok = $true; $reason = "ok"
    try {
        if ($SIEM_PROTOCOL -eq "tcp") {
            $t = Connect-Tcp; $t.Close()
        } else {
            $u = New-Object System.Net.Sockets.UdpClient
            try {
                $u.Connect($SYSLOG_HOST, $SYSLOG_PORT)
                $hb = "<14>1 $(ConvertTo-IsoUtc $null) $($env:COMPUTERNAME) windsurf-cascade - - - event_type=HEARTBEAT user=$($env:USERNAME)"
                $b = [System.Text.Encoding]::UTF8.GetBytes($hb)
                [void]$u.Send($b, $b.Length)
                $u.Client.ReceiveTimeout = 300
                try {
                    $ep = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
                    [void]$u.Receive([ref]$ep)
                } catch [System.Net.Sockets.SocketException] {
                    # Un timeout es lo normal en syslog (nadie responde). Cualquier otro error = problema.
                    if ($_.Exception.SocketErrorCode -ne [System.Net.Sockets.SocketError]::TimedOut) { throw }
                }
            } finally { $u.Close() }
        }
    } catch { $ok = $false; $reason = [string]$_.Exception.Message }
    Set-SiemCache $ok $reason
    return @{ ok = $ok; reason = $reason; cached = $false }
}

function Add-Spool([string[]]$messages) {
    try {
        if ((Test-Path $SPOOL_FILE) -and ((Get-Item $SPOOL_FILE).Length -gt $SPOOL_MAX_BYTES)) {
            Write-ErrLog "cola local llena ($SPOOL_MAX_BYTES bytes): evento descartado del reenvio (sigue en audit.jsonl)"
            return
        }
        $text = ($messages -join "`n") + "`n"
        for ($i = 1; $i -le 4; $i++) {
            try { [System.IO.File]::AppendAllText($SPOOL_FILE, $text, [System.Text.UTF8Encoding]::new($false)); return }
            catch { Start-Sleep -Milliseconds (40 * $i) }
        }
    } catch { Write-ErrLog "no se pudo escribir la cola local: $_" }
}

function Invoke-SpoolFlush {
    # Reenvia eventos que quedaron pendientes (equipo sin red/VPN). Conservan su timestamp original.
    if (-not (Test-Path $SPOOL_FILE)) { return }
    $tmp = "$SPOOL_FILE.$([guid]::NewGuid().ToString('N')).flush"
    try { Move-Item -Path $SPOOL_FILE -Destination $tmp -ErrorAction Stop } catch { return }
    $lines = @([System.IO.File]::ReadAllLines($tmp, [System.Text.Encoding]::UTF8) | Where-Object { $_ })
    $toSend = @($lines | Select-Object -First $SPOOL_FLUSH_MAX)
    $rest   = @($lines | Select-Object -Skip $SPOOL_FLUSH_MAX)
    try {
        if ($toSend.Count -gt 0) { Send-Siem $toSend }
        if ($rest.Count -gt 0) { Add-Spool $rest }
        Remove-Item $tmp -Force -ErrorAction SilentlyContinue
    } catch {
        Add-Spool $lines
        Remove-Item $tmp -Force -ErrorAction SilentlyContinue
        throw
    }
}

function ConvertTo-Text($v) {
    if ($null -eq $v) { return "" }
    if ($v -is [string]) { return $v }
    return ($v | ConvertTo-Json -Compress -Depth 6)
}

# ---------- main ----------
$exitCode = 0
$hook = ""
try {
    if (-not (Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Force -Path $LOG_DIR | Out-Null }

    # --- politica ---
    $policy = $null; $policySha = "none"
    try {
        if (Test-Path $POLICY_FILE) {
            $policyText = Get-Content -Raw -Encoding UTF8 -Path $POLICY_FILE
            $policy     = $policyText | ConvertFrom-Json
            $policySha  = Get-Sha256 $policyText
        } else { Write-ErrLog "policy.json no encontrado ($POLICY_FILE): solo-auditoria" }
    } catch { Write-ErrLog "policy.json invalido: $_"; $policy = $null }
    $enforce = ($ALLOW_BLOCKING -and $null -ne $policy -and $policy.mode -eq "enforce")

    # --- entrada (stdin UTF-8) ---
    $reader = New-Object System.IO.StreamReader([Console]::OpenStandardInput(), [System.Text.UTF8Encoding]::new($false))
    $raw = $reader.ReadToEnd()
    if ([string]::IsNullOrWhiteSpace($raw)) { Write-ErrLog "stdin vacio"; exit 0 }

    Write-Trace ("stdin recibido: {0} caracteres | inicio: {1}" -f $raw.Length, $raw.Substring(0, [Math]::Min(200, $raw.Length)))
    $data = $raw | ConvertFrom-Json
    $hook = if ($data.agent_action_name) { [string]$data.agent_action_name } else { "unknown" }
    $isPre = $hook.StartsWith("pre_")
    $tool = $data.tool_info

    # --- conectividad con el SIEM (con cache para no agregar latencia en cada hook) ---
    $siem = @{ ok = $true; reason = "no verificado"; cached = $false }
    if ($SEND_TO_SIEM -and $SIEM_CHECK) { $siem = Test-Siem }
    $siemStatus = if (-not $SEND_TO_SIEM) { "DISABLED" } elseif ($siem.ok) { "OK" } else { "UNREACHABLE" }
    if ($siemStatus -eq "UNREACHABLE" -and -not $siem.cached) {
        Write-ErrLog "SIEM inalcanzable (${SYSLOG_HOST}:${SYSLOG_PORT}/$SIEM_PROTOCOL): $($siem.reason)"
    }

    Write-Trace ("hook={0} | siem ok={1} cacheado={2} motivo={3}" -f $hook, $siem.ok, $siem.cached, $siem.reason)

    # Verifica los nombres de campo de tool_info contra la documentacion de tu version de Windsurf.
    $extra = [ordered]@{}
    switch ($hook) {
        "pre_user_prompt"       { $etype = "USER_PROMPT";    $content = $tool.user_prompt }
        "post_cascade_response" { $etype = "AGENT_RESPONSE"; $content = $tool.response }
        "pre_run_command"       { $etype = "COMMAND_EXEC";   $content = $tool.command_line; $extra["cwd"] = [string]$tool.cwd }
        "pre_mcp_tool_use"      { $etype = "MCP_TOOL_USE";   $content = $tool.mcp_tool_arguments
                                  $extra["mcp_server"] = [string]$tool.mcp_server_name
                                  $extra["mcp_tool"]   = [string]$tool.mcp_tool_name }
        { $_ -in "pre_read_code","post_read_code" }   { $etype = "FILE_READ";  $content = $tool.file_path }
        { $_ -in "pre_write_code","post_write_code" } { $etype = "FILE_WRITE"; $content = $tool.file_path }
        default                 { $etype = $hook.ToUpper();  $content = $tool }
    }
    $content = ConvertTo-Text $content

    # --- evaluacion de politica (solo hooks pre_*, unicos que pueden bloquear) ---
    $hits = @()
    if ($isPre -and $null -ne $policy) {
        switch ($etype) {
            "USER_PROMPT"  { $hits = @(Test-Rules $content $policy.prompt_rules) }
            "COMMAND_EXEC" { $hits = @(Test-Rules $content $policy.command_rules) }
            "FILE_READ"    { $hits = @(Test-Rules $content $policy.file_rules) }
            "FILE_WRITE"   { $hits = @(Test-Rules $content $policy.file_rules) }
            "MCP_TOOL_USE" {
                $allowed = @($policy.mcp.allowed_servers | Where-Object { $_ })
                if ($allowed.Count -gt 0 -and ($allowed -notcontains $extra["mcp_server"])) {
                    $hits = @([pscustomobject]@{ id = "M001"; action = "block"; message = "Servidor MCP no autorizado." })
                }
            }
        }
    }

    $decision = "ALLOW"; $ruleIds = @(); $blocking = $null
    foreach ($h in $hits) {
        $ruleIds += [string]$h.id
        if ($h.action -eq "block" -and -not $blocking) { $blocking = $h }
    }
    if ($blocking) {
        if ($enforce) { $decision = "BLOCK" } else { $decision = "WOULD_BLOCK" }
    } elseif ($hits.Count -gt 0) {
        $decision = "FLAGGED"
    }
    if ($decision -eq "BLOCK") { $exitCode = 2 }

    # Sin SIEM no hay auditoria: bloqueo opcional (requiere ambos interruptores en $true)
    if ($isPre -and $siemStatus -eq "UNREACHABLE" -and $BLOCK_IF_SIEM_DOWN -and $ALLOW_BLOCKING -and $exitCode -ne 2) {
        $decision = "BLOCK"; $exitCode = 2
        $blocking = [pscustomobject]@{ id = "S001"; action = "block"; message = "No hay conectividad con el sistema de auditoria (SIEM). Conectate a la red o VPN corporativa e intenta de nuevo." }
        $ruleIds += "S001"
    }

    $ts      = ConvertTo-IsoUtc $null     # hora de recoleccion en este equipo (UTC): evita desfases por la hora que mande Windsurf
    $srcTs   = [string]$data.timestamp    # hora original reportada por Windsurf (solo informativa)
    $model   = if ($data.model_name) { [string]$data.model_name } else { "unknown" }
    $eventId = [guid]::NewGuid().ToString()
    $sha     = Get-Sha256 $content
    $rulesStr = ($ruleIds -join ",")

    Write-Trace ("evento {0} decision={1} reglas={2} contenido={3} caracteres | ts_equipo={4} ts_windsurf={5}" -f $etype, $decision, $rulesStr, $content.Length, $ts, $srcTs)

    # --- 1. Log local ---
    $localContent = $content; $localRedactions = 0
    if ($REDACT_LOCAL) { $r = Protect-Secrets $content; $localContent = $r.Text; $localRedactions = $r.Count }

    $evt = [ordered]@{
        event_id       = $eventId
        event_type     = $etype
        hook           = $hook
        decision       = $decision
        rule_ids       = $rulesStr
        policy_sha256  = $policySha
        timestamp      = $ts
        windsurf_timestamp = $srcTs
        trajectory_id  = $data.trajectory_id
        execution_id   = $data.execution_id
        host           = $env:COMPUTERNAME
        user           = $env:USERNAME
        user_domain    = $env:USERDOMAIN
        source         = "windsurf-cascade"
        model          = $model
        content_length = $content.Length
        content_sha256 = $sha
        redactions     = $localRedactions
        siem_status    = $siemStatus
    }
    foreach ($k in $extra.Keys) { $evt[$k] = $extra[$k] }
    $evt["content"] = $localContent

    if (-not (Write-LocalLog ($evt | ConvertTo-Json -Compress -Depth 6))) {
        Write-ErrLog "no se pudo escribir audit.jsonl (evento $eventId)"
    }

    Write-Trace "log local escrito"

    # --- 2. SIEM ---
    if ($SEND_TO_SIEM -and ($SIEM_EVENT_TYPES -contains $etype)) {
        $siemContent = $content; $siemRedactions = 0
        if ($REDACT_SIEM) { $r = Protect-Secrets $content; $siemContent = $r.Text; $siemRedactions = $r.Count }

        if ($SIEM_FORMAT -eq "legacy") {
            # Formato del script original: un solo datagrama, mismos campos y mismo orden.
            # Hora de la cabecera = hora del equipo (UTC, 3 decimales, valida en RFC 5424).
            # La hora que manda Windsurf puede traer 9 decimales (invalida para RFC 5424: max. 6).
            $hdrTs = $ts
            $marker = ""
            $cText = $siemContent
            do {
                $legacyMsg = "<14>1 $hdrTs $($env:COMPUTERNAME) windsurf-cascade - - - " +
                             "event_type=$etype " +
                             "user=$($env:USERNAME) " +
                             "model=$model " +
                             "trajectory_id=$($data.trajectory_id) " +
                             "execution_id=$($data.execution_id) " +
                             "content=$(ConvertTo-JsonString ($cText + $marker))"
                $tooBig = ([System.Text.Encoding]::UTF8.GetByteCount($legacyMsg) -gt $LEGACY_MAX_BYTES)
                if ($tooBig) {
                    $marker = "...[truncado]"
                    $cText = $cText.Substring(0, [int]($cText.Length * 0.8))
                }
            } while ($tooBig -and $cText.Length -gt 100)
            $msgs = @($legacyMsg)
        } else {
        $chunks = Split-Chunks $siemContent $CHUNK_CHARS
        $truncated = $false
        if ($chunks.Count -gt $MAX_CHUNKS) { $chunks = $chunks.GetRange(0, $MAX_CHUNKS); $truncated = $true }
        $total = $chunks.Count
        $spoolFlag = if ($siem.ok) { "" } else { "spooled=true " }

        # Severidad syslog: BLOCK=err(11), WOULD_BLOCK/FLAGGED=warning(12), resto=info(14)
        $pri = switch ($decision) { "BLOCK" { 11 } "WOULD_BLOCK" { 12 } "FLAGGED" { 12 } default { 14 } }

        $extraKv = ""
        foreach ($k in $extra.Keys) { $extraKv += "$k=$(ConvertTo-JsonString $extra[$k]) " }

        $msgs = @()
        for ($i = 0; $i -lt $total; $i++) {
            $msgs += "<$pri>1 $ts $($env:COMPUTERNAME) windsurf-cascade - - - " +
                     "event_id=$eventId " +
                     "event_type=$etype " +
                     "decision=$decision " +
                     "rule_ids=$(ConvertTo-JsonString $rulesStr) " +
                     "user=$($env:USERNAME) " +
                     "model=$model " +
                     "trajectory_id=$($data.trajectory_id) " +
                     "execution_id=$($data.execution_id) " +
                     "src_ts=$(ConvertTo-JsonString $srcTs) " +
                     "part=$($i + 1)/$total " +
                     "truncated=$($truncated.ToString().ToLower()) " +
                     "redactions=$siemRedactions " +
                     $spoolFlag +
                     "content_sha256=$sha " +
                     $extraKv +
                     "content=$(ConvertTo-JsonString $chunks[$i])"
        }
        }
        Write-Trace ("mensajes a enviar: {0} (bytes: {1})" -f $msgs.Count, (($msgs | ForEach-Object { [System.Text.Encoding]::UTF8.GetByteCount($_) }) -join ","))
        Write-Trace ("primer mensaje: " + $msgs[0])
        if ($siem.ok) {
            try {
                Invoke-SpoolFlush      # primero lo pendiente, para conservar el orden
                Send-Siem $msgs
                Write-Trace "envio al SIEM terminado sin errores"
            } catch {
                Write-ErrLog "envio al SIEM fallo; evento a cola local: $_"
                Set-SiemCache $false ([string]$_.Exception.Message)
                Add-Spool $msgs
            }
        } else {
            Write-Trace "SIEM marcado como inalcanzable: evento a la cola local, NO se envio"
            Add-Spool $msgs
        }
    }

    # --- 3. Bloqueo: mensaje para el usuario (no se repite el contenido detectado) ---
    if ($decision -eq "BLOCK") {
        $msg = if ($blocking.message) { [string]$blocking.message } else { "Accion no permitida por la politica." }
        [Console]::Error.WriteLine("[Seguridad] Accion bloqueada (regla $($blocking.id)): $msg Si crees que es un error, contacta al equipo de seguridad con el ID $eventId.")
    }
}
catch {
    Write-ErrLog ("error: {0} (linea {1})" -f $_, $_.InvocationInfo.ScriptLineNumber)
    Write-Trace ("ERROR: {0} (linea {1})" -f $_, $_.InvocationInfo.ScriptLineNumber)
    if ($ALLOW_BLOCKING -and $FAIL_CLOSED -and $hook.StartsWith("pre_")) {
        [Console]::Error.WriteLine("[Seguridad] No se pudo verificar la politica de auditoria; accion bloqueada por precaucion.")
        $exitCode = 2
    }
}

exit $exitCode
