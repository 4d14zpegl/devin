#Requires -Version 5.1
<#
  ver_logs.ps1 - Visor del log local de Windsurf Audit (audit.jsonl)

  Ejemplos:
    .\ver_logs.ps1                          # ultimos 50 eventos, en tabla
    .\ver_logs.ps1 -Last 200                # ultimos 200
    .\ver_logs.ps1 -Today                   # solo los de hoy
    .\ver_logs.ps1 -Type USER_PROMPT        # solo prompts
    .\ver_logs.ps1 -Decision WOULD_BLOCK    # solo eventos de riesgo
    .\ver_logs.ps1 -Search "terraform"      # buscar texto
    .\ver_logs.ps1 -Full                    # detalle completo, un bloque por evento
    .\ver_logs.ps1 -Grid                    # ventana con tabla ordenable/filtrable
    .\ver_logs.ps1 -All -Csv "$env:USERPROFILE\Desktop\auditoria.csv"   # exportar para Excel

  Tipos:      USER_PROMPT, AGENT_RESPONSE, COMMAND_EXEC, FILE_READ, FILE_WRITE, MCP_TOOL_USE
  Decisiones: ALLOW, FLAGGED, WOULD_BLOCK, BLOCK
  Solo LEE el log; no modifica nada.
#>
param(
    [int]$Last = 50,
    [string]$Type,
    [string]$Decision,
    [string]$Search,
    [switch]$Today,
    [switch]$All,      # incluye los archivos rotados (audit-*.jsonl)
    [switch]$Full,
    [switch]$Grid,
    [string]$Csv
)

$dir  = Join-Path $env:USERPROFILE "windsurf-audit"
$main = Join-Path $dir "audit.jsonl"

if (-not (Test-Path $dir)) { Write-Warning "No existe $dir. Aun no hay logs."; return }

$files = @()
if ($All) { $files += Get-ChildItem $dir -Filter "audit-*.jsonl" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime }
if (Test-Path $main) { $files += Get-Item $main }
if ($files.Count -eq 0) { Write-Warning "No hay archivos de log en $dir."; return }

function ConvertTo-LocalTime($ts) {
    try {
        if ($ts -is [datetime]) { return $ts.ToLocalTime() }
        return ([datetime]::Parse([string]$ts)).ToLocalTime()
    } catch { return $null }
}

# ---- leer y parsear (las lineas corruptas se ignoran) ----
$events = New-Object System.Collections.Generic.List[object]
$bad = 0
foreach ($f in $files) {
    foreach ($line in [System.IO.File]::ReadLines($f.FullName, [System.Text.Encoding]::UTF8)) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        try {
            $e = $line | ConvertFrom-Json
            $e | Add-Member -NotePropertyName local_time -NotePropertyValue (ConvertTo-LocalTime $e.timestamp) -Force
            $events.Add($e)
        } catch { $bad++ }
    }
}

# ---- filtros ----
$sel = $events | Sort-Object { $_.local_time }
if ($Today)    { $d0 = (Get-Date).Date; $sel = $sel | Where-Object { $_.local_time -and $_.local_time -ge $d0 } }
if ($Type)     { $sel = $sel | Where-Object { $_.event_type -eq $Type.ToUpper() } }
if ($Decision) { $sel = $sel | Where-Object { $_.decision   -eq $Decision.ToUpper() } }
if ($Search)   { $sel = $sel | Where-Object { ($_.content -like "*$Search*") -or ($_.rule_ids -like "*$Search*") -or ($_.mcp_tool -like "*$Search*") } }
$sel = @($sel)
$totalMatch = $sel.Count

# ---- exportar a CSV (todo lo filtrado, sin limite de -Last) ----
if ($Csv) {
    $sel | ForEach-Object {
        [pscustomobject]@{
            Hora       = if ($_.local_time) { $_.local_time.ToString("yyyy-MM-dd HH:mm:ss") } else { "" }
            Tipo       = $_.event_type
            Decision   = $_.decision
            Reglas     = $_.rule_ids
            Usuario    = $_.user
            Equipo     = $_.host
            Modelo     = $_.model
            Conversacion = $_.trajectory_id
            Contenido  = ([string]$_.content -replace '\s+', ' ')
            EventId    = $_.event_id
        }
    } | Export-Csv -Path $Csv -NoTypeInformation -Encoding UTF8
    Write-Host "Exportados $totalMatch eventos a $Csv"
    return
}

$sel = @($sel | Select-Object -Last $Last)

# ---- ventana ordenable/filtrable ----
if ($Grid) {
    $sel | ForEach-Object {
        [pscustomobject]@{
            Hora      = if ($_.local_time) { $_.local_time.ToString("yyyy-MM-dd HH:mm:ss") } else { "" }
            Tipo      = $_.event_type
            Decision  = $_.decision
            Reglas    = $_.rule_ids
            Usuario   = $_.user
            Modelo    = $_.model
            Contenido = ([string]$_.content -replace '\s+', ' ')
        }
    } | Out-GridView -Title "Windsurf Audit - $($sel.Count) eventos"
    return
}

function Get-Color($dec) {
    switch ($dec) {
        "BLOCK"       { "Red" }
        "WOULD_BLOCK" { "Yellow" }
        "FLAGGED"     { "Cyan" }
        default       { "Gray" }
    }
}

if ($sel.Count -eq 0) { Write-Host "Sin eventos para esos filtros."; return }

if ($Full) {
    # ---- detalle completo ----
    foreach ($e in $sel) {
        $t = if ($e.local_time) { $e.local_time.ToString("yyyy-MM-dd HH:mm:ss") } else { "?" }
        Write-Host ("=" * 78) -ForegroundColor DarkGray
        Write-Host ("{0}  {1}  [{2}]" -f $t, $e.event_type, $e.decision) -ForegroundColor (Get-Color $e.decision)
        Write-Host ("Usuario: {0}   Equipo: {1}   Modelo: {2}" -f $e.user, $e.host, $e.model)
        if ($e.rule_ids) { Write-Host ("Reglas:  {0}" -f $e.rule_ids) -ForegroundColor Yellow }
        if ($e.cwd)      { Write-Host ("Carpeta: {0}" -f $e.cwd) }
        if ($e.mcp_server) { Write-Host ("MCP:     {0} / {1}" -f $e.mcp_server, $e.mcp_tool) }
        Write-Host ("Conversacion: {0}   Evento: {1}" -f $e.trajectory_id, $e.event_id) -ForegroundColor DarkGray
        Write-Host "--"
        Write-Host $e.content
    }
    Write-Host ("=" * 78) -ForegroundColor DarkGray
} else {
    # ---- tabla compacta con colores ----
    $w = 120
    try { $w = $Host.UI.RawUI.WindowSize.Width } catch { }
    $cw = [Math]::Max(30, $w - 52)

    Write-Host ("{0,-14} {1,-15} {2,-11} {3,-10} {4}" -f "HORA", "TIPO", "DECISION", "USUARIO", "CONTENIDO") -ForegroundColor White
    Write-Host ("-" * ([Math]::Min($w - 1, 118))) -ForegroundColor DarkGray
    foreach ($e in $sel) {
        $t = if ($e.local_time) { $e.local_time.ToString("MM-dd HH:mm:ss") } else { "?" }
        $c = ([string]$e.content -replace '\s+', ' ').Trim()
        if ($c.Length -gt $cw) { $c = $c.Substring(0, $cw - 3) + "..." }
        $u = [string]$e.user; if ($u.Length -gt 10) { $u = $u.Substring(0, 10) }
        Write-Host ("{0,-14} {1,-15} {2,-11} {3,-10} {4}" -f $t, $e.event_type, $e.decision, $u, $c) -ForegroundColor (Get-Color $e.decision)
    }
}

# ---- resumen ----
Write-Host ""
$byType = $sel | Group-Object event_type | ForEach-Object { "{0}: {1}" -f $_.Name, $_.Count }
$byDec  = $sel | Group-Object decision   | ForEach-Object { "{0}: {1}" -f $_.Name, $_.Count }
Write-Host ("Mostrando {0} de {1} eventos que coinciden." -f $sel.Count, $totalMatch) -ForegroundColor White
Write-Host ("Por tipo:     " + ($byType -join "  |  "))
Write-Host ("Por decision: " + ($byDec  -join "  |  "))
if ($bad -gt 0) { Write-Warning "$bad linea(s) corrupta(s) ignoradas." }
