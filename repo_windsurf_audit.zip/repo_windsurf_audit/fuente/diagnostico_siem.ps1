#Requires -Version 5.1
<#
  diagnostico_siem.ps1 - Diagnostico de envio al SIEM (Windsurf Audit)

  Uso:
    powershell -ExecutionPolicy Bypass -File .\diagnostico_siem.ps1
    powershell -ExecutionPolicy Bypass -File .\diagnostico_siem.ps1 -HostName 192.168.52.49 -Port 514

  Que hace (no modifica nada del sistema):
    1. Muestra IPs del equipo y la ruta hacia el SIEM
    2. Hace ping
    3. Muestra el estado del script: cache de conectividad, cola pendiente, errores recientes
    4. Envia 3 datagramas UDP de prueba (pequeno / mediano / grande) con un MARCADOR unico
    5. Te dice que pedirle a seguridad para ubicar el punto de falla
#>
param([string]$HostName, [int]$Port)

$hooksDir = Join-Path $env:USERPROFILE "hooks"
$auditDir = Join-Path $env:USERPROFILE "windsurf-audit"
$installed = Join-Path $hooksDir "windsurf_audit.ps1"

# Tomar host/puerto del script instalado si no se pasaron
if ((-not $HostName -or -not $Port) -and (Test-Path $installed)) {
    $txt = Get-Content -Raw -Path $installed
    if (-not $HostName -and $txt -match '\$SYSLOG_HOST\s*=\s*"([^"]+)"') { $HostName = $Matches[1] }
    if (-not $Port     -and $txt -match '\$SYSLOG_PORT\s*=\s*(\d+)')     { $Port = [int]$Matches[1] }
}
if (-not $HostName) { $HostName = "192.168.52.49" }
if (-not $Port)     { $Port = 514 }

function Title([string]$t) { Write-Host ""; Write-Host "=== $t ===" -ForegroundColor Cyan }

Write-Host "Diagnostico SIEM  ->  ${HostName}:${Port}/UDP   ($(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))"

# ---------- 1. Red ----------
Title "1. Red del equipo"
try {
    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
        Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" } |
        ForEach-Object { "  {0}   ({1})" -f $_.IPAddress, $_.InterfaceAlias }
} catch { Write-Host "  (no se pudo leer las IP locales: $($_.Exception.Message))" }
try {
    $rt = Find-NetRoute -RemoteIPAddress $HostName -ErrorAction Stop |
          Where-Object { $_.PSObject.Properties.Name -contains "NextHop" } | Select-Object -First 1
    if ($rt) { Write-Host ("  Ruta al SIEM: interfaz '{0}' via {1}" -f $rt.InterfaceAlias, $rt.NextHop) }
} catch { Write-Host "  Ruta al SIEM: no se pudo determinar ($($_.Exception.Message))" -ForegroundColor Yellow }

# ---------- 2. Ping ----------
Title "2. Ping (ICMP; puede estar bloqueado aunque el UDP funcione)"
try {
    if (Test-Connection -ComputerName $HostName -Count 2 -Quiet -ErrorAction Stop) {
        Write-Host "  Responde al ping" -ForegroundColor Green
    } else { Write-Host "  Sin respuesta al ping" -ForegroundColor Yellow }
} catch { Write-Host "  Ping fallo: $($_.Exception.Message)" -ForegroundColor Yellow }

# ---------- 3. Estado del script ----------
Title "3. Estado del script de auditoria"
if (Test-Path $installed) { Write-Host "  Script instalado: $installed" } else { Write-Host "  NO esta instalado en $installed" -ForegroundColor Red }

$statusFile = Join-Path $auditDir "siem-status.json"
if (Test-Path $statusFile) {
    try {
        $st = Get-Content -Raw $statusFile | ConvertFrom-Json
        $age = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - [int64]$st.t
        $color = if ($st.ok) { "Green" } else { "Red" }
        Write-Host ("  Ultima verificacion (hace {0}s): ok={1}  motivo={2}" -f $age, $st.ok, $st.reason) -ForegroundColor $color
    } catch { Write-Host "  siem-status.json ilegible" }
} else { Write-Host "  Aun no hay siem-status.json (el script no ha verificado conectividad)" }

$spool = Join-Path $auditDir "siem-spool.jsonl"
if (Test-Path $spool) {
    $n = @(Get-Content $spool | Where-Object { $_ }).Count
    $kb = [Math]::Round((Get-Item $spool).Length / 1KB, 1)
    $color = if ($n -gt 0) { "Yellow" } else { "Green" }
    Write-Host ("  Cola pendiente de reenvio: {0} mensajes ({1} KB)" -f $n, $kb) -ForegroundColor $color
} else { Write-Host "  Cola pendiente: vacia (no existe siem-spool.jsonl)" -ForegroundColor Green }

$errLog = Join-Path $auditDir "errors.log"
if (Test-Path $errLog) {
    Write-Host "  Ultimos errores (errors.log):"
    Get-Content $errLog -Tail 8 | ForEach-Object { "    $_" }
} else { Write-Host "  errors.log: sin errores registrados" -ForegroundColor Green }

$audit = Join-Path $auditDir "audit.jsonl"
if (Test-Path $audit) {
    try {
        $last = Get-Content $audit -Tail 1 | ConvertFrom-Json
        Write-Host ("  Ultimo evento local: {0}  {1}  siem_status={2}" -f $last.timestamp, $last.event_type, $last.siem_status)
    } catch { }
}

# ---------- 4. Datagramas de prueba ----------
Title "4. Envio UDP de prueba (3 tamanos)"
$marker = "DIAG-" + [guid]::NewGuid().ToString().Substring(0, 8)
$ts = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
$tests = @( @{ n = "pequeno"; target = 200 }, @{ n = "mediano"; target = 900 }, @{ n = "grande"; target = 1800 } )

$udp = New-Object System.Net.Sockets.UdpClient
try {
    $udp.Connect($HostName, $Port)
    foreach ($t in $tests) {
        $prefix = "<14>1 $ts $($env:COMPUTERNAME) windsurf-cascade - - - event_type=DIAG marker=$marker size=$($t.n) content="
        $pad = "x" * [Math]::Max(1, $t.target - $prefix.Length)
        $msg = $prefix + '"' + $pad + '"'
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($msg)
        try {
            $sent = $udp.Send($bytes, $bytes.Length)
            Write-Host ("  [{0,-8}] enviados {1} bytes" -f $t.n, $sent) -ForegroundColor Green
        } catch {
            Write-Host ("  [{0,-8}] ERROR al enviar: {1}" -f $t.n, $_.Exception.Message) -ForegroundColor Red
        }
        Start-Sleep -Milliseconds 150
    }
    # Un ICMP "puerto inaccesible" aparece como error en la siguiente lectura
    $udp.Client.ReceiveTimeout = 700
    try {
        $ep = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
        [void]$udp.Receive([ref]$ep)
    } catch [System.Net.Sockets.SocketException] {
        if ($_.Exception.SocketErrorCode -eq [System.Net.Sockets.SocketError]::TimedOut) {
            Write-Host "  Sin respuesta ICMP (normal en syslog; no descarta perdida de paquetes)." -ForegroundColor Gray
        } else {
            Write-Host ("  ATENCION: {0}  -> en esa IP no hay nada escuchando UDP {1}, o hay un rechazo explicito." -f $_.Exception.SocketErrorCode, $Port) -ForegroundColor Red
        }
    }
} catch {
    Write-Host "  No se pudo abrir el socket hacia ${HostName}:${Port}: $($_.Exception.Message)" -ForegroundColor Red
} finally { $udp.Close() }

# ---------- 5. Siguiente paso ----------
Title "5. Que pedirle a seguridad"
Write-Host "  Marcador de esta prueba : $marker"
Write-Host "  Hora (UTC)              : $ts"
Write-Host "  Equipo                  : $($env:COMPUTERNAME)"
Write-Host ""
Write-Host "  a) En el colector de Exabeam, captura de paquetes (ajusta la IP de este equipo):"
Write-Host "       tcpdump -ni any udp port $Port and host <IP_DE_ESTE_EQUIPO> -c 20"
Write-Host "  b) En Exabeam, buscar el texto: $marker"
Write-Host ""
Write-Host "  Interpretacion:"
Write-Host "   - No aparece en tcpdump            -> red/firewall/VPN descarta los paquetes."
Write-Host "   - Aparece en tcpdump, no en Exabeam -> el colector lo recibe pero lo descarta o no lo parsea"
Write-Host "                                          (origen no registrado como fuente, o parser)."
Write-Host "   - Llega solo el 'pequeno'           -> hay limite de tamano de datagrama en el camino/colector."
Write-Host "   - Llegan los 3                      -> el envio funciona; revisar el parser para el formato real."
